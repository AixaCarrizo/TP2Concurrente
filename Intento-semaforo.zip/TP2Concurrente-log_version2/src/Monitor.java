import java.util.concurrent.Semaphore;

public class Monitor {
    private Object Cons, Produc;
    private int contProd = 0;
    private int contCons=0;

    private Buffer buffer1 = new Buffer();
    private Buffer buffer2 = new Buffer();

    private final Semaphore Semaforo = new Semaphore(1);
    private final Semaphore SemaforoC = new Semaphore(1);
    private final Semaphore SemaforoP = new Semaphore(1);

    private PN pn = new PN();

    public int shoot(int index) {  //Dispara una transicion (index)
        try {
            Semaforo.acquire();
        } catch (InterruptedException e) {
        e.printStackTrace();
        }
        if(contProd==1000){
            System.out.println("VG");
        }
        if (index == 1) {
            while (true) {
                //System.out.println("A");
                if(SemaforoP.hasQueuedThreads()){
                    if(Semaforo.availablePermits()<1) {
                        //System.out.println("B");
                        Semaforo.release();
                    }
                }
                try {
                    SemaforoP.acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (pn.isPos(index)) {    //Si es posible usar el Buffer1.
                    Semaforo.release();
                    SemaforoP.release();
                    return 1;
                } else if (pn.isPos(2)) { //Si es posible usar el Buffer2.
                    Semaforo.release();
                    SemaforoP.release();
                    return 2;
                }
                Semaforo.release();
            }
        } else {
            while (true) {
                if(SemaforoC.hasQueuedThreads()){
                    if(Semaforo.availablePermits()<1) {
                        Semaforo.release();
                    }
                }
                try {
                    SemaforoC.acquire();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (pn.isPos(index)) {    //Si es posible usar el Buffer1.
                    Semaforo.release();
                    SemaforoC.release();
                    return 1;
                } else if (pn.isPos(3)) {    //Si es posible usar el Buffer2.
                    Semaforo.release();
                    SemaforoC.release();
                    return 2;
                } else if (contProd == 5000 && contCons == 5000) { //Esto solo le interesa al Consumidor. El Productor muere solo.
                    SemaforoC.release();
                    Semaforo.release();
                    return -1;
                }
                Semaforo.release();
            }
        }
    }

    public void agregar(String id, int idBuffer) {
        try {
            Semaforo.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        contProd++;
        if (idBuffer == 1) {
            buffer1.add(id);
            pn.isPos(6);
            System.out.println("Agregue al buffer 1");
        } else {

            buffer2.add(id);
            pn.isPos(7);
            System.out.println("Agregue al buffer 2");
        }

        if (SemaforoC.hasQueuedThreads()) {
            SemaforoC.release();
        }
        else{
            Semaforo.release();
        }
    }

    public void quitar(int idBuffer){
        try {
            Semaforo.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        contCons++;

        if(idBuffer==1) {

            buffer1.remove();
            pn.isPos(5);
            //System.out.println("Consumi del buffer 1");
        }
        else {

            buffer2.remove();
            pn.isPos(4);
            //System.out.println("Consumi del buffer 2");
        }
        if (SemaforoP.hasQueuedThreads()) {
            SemaforoP.release();
        }
        else{
            Semaforo.release();
        }
    }
}
